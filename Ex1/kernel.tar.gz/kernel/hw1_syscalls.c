
#include <asm/param.h>
#include <linux/config.h>
#include <linux/binfmts.h>
#include <linux/threads.h>
#include <linux/kernel.h>
#include <linux/types.h>
#include <linux/times.h>
#include <linux/timex.h>
#include <linux/rbtree.h>

#include <asm/system.h>
#include <asm/semaphore.h>
#include <asm/page.h>
#include <asm/ptrace.h>
#include <asm/mmu.h>

#include <linux/smp.h>
#include <linux/tty.h>
#include <linux/sem.h>
#include <linux/signal.h>
#include <linux/securebits.h>
#include <linux/fs_struct.h>
#include <linux/low-latency.h>
#include <linux/sched.h>
#include <linux/slab.h>

int sys_enable_policy(pid_t pid, int size, int password) {
	if (pid < 0){
		return -ESRCH;
	}
	task_t* _SA_p = find_task_by_pid(pid);
	if (_SA_p == 0 || _SA_p->pid != pid){
		return -ESRCH;
	}
	if (password != 234123){
		return -EINVAL;
	}
	if (_SA_p->_SA_policy_flag == 1){
		return -EINVAL;
	}
	if (size < 0){
		return -EINVAL;
	}

	_SA_p->_SA_log_arr = kmalloc(size*(sizeof(struct forbidden_activity_info)), GFP_KERNEL);
	if (_SA_p->_SA_log_arr == NULL){
		return -ENOMEM;
	}

	int i;
	for (i=0; i<size; i++){
		_SA_p->_SA_log_arr[i].syscall_req_level = -1;
		_SA_p->_SA_log_arr[i].proc_level = -1;
		_SA_p->_SA_log_arr[i].time = -1;
	}
	_SA_p->_SA_log_size = size;
	_SA_p->_SA_policy_flag = 1;
//	printk("===================== Gotin - Enable Poly ===================\n");
	return 0;
}


int sys_disable_policy(pid_t pid, int password){
	if (pid < 0){
		return -ESRCH;
	}
	task_t* _SA_p = find_task_by_pid(pid);
	if (_SA_p == 0 || _SA_p->pid != pid){
		return -ESRCH;
	}
	if(_SA_p->_SA_policy_flag == 0){
		return -EINVAL;
	}
	if (password != 234123){
		return -EINVAL;
	}

	kfree(_SA_p->_SA_log_arr);
	_SA_p->_SA_log_arr = NULL;
	_SA_p->_SA_policy_flag = 0;
	return 0;
}


int sys_set_process_capabilities (pid_t pid, int new_level, int password){
	if (pid < 0){
		return -ESRCH;
	}
	task_t* _SA_p = find_task_by_pid(pid);
	if (_SA_p == 0 || _SA_p->pid != pid){
		return -ESRCH;
	}
	if (new_level != 0 && new_level != 1 && new_level != 2){
		return -EINVAL;
	}
	if (_SA_p->_SA_policy_flag == 0){
		return -EINVAL;
	}

	_SA_p->_SA_privilege_level = new_level;
//	printk("===================== Gotin - Set Privilege ===================\n");
	return 0;
}

int sys_get_process_log (pid_t pid, int size, struct forbidden_activity_info* user_mem) {
	if (pid < 0){
		return -ESRCH;
	}
	task_t* _SA_p = find_task_by_pid(pid);
//	printk("Insdie get_log, the ptr of the process is: %d\n", _SA_p);
	if (_SA_p == 0 || _SA_p->pid != pid){
		return -ESRCH;
	}
	/* add the log shtut struct */		
	int number_of_rec = 0;
	int i;
	for (i=0; i< _SA_p->_SA_log_size; i++){
		if (_SA_p->_SA_log_arr[i].syscall_req_level == -1){
			if (i == 0){
				number_of_rec = -1;
				break;
			} else {
				number_of_rec = i;
				break;
			}
		}
	}
//	printk("The Number of Logs is: %d and i is: %d\n", number_of_rec, i);
	if ((_SA_p->_SA_log_arr != NULL && _SA_p->_SA_log_arr[0].syscall_req_level == -1 && size != 0) || i < size){
		return -EINVAL;
	}
	if (size <0){
		return -EINVAL;
	}
	if (_SA_p->_SA_policy_flag == 0){
		return -EINVAL;
	}
	number_of_rec = i;

	for (i=0; i < size; i++){
//		printk("KUKU1\n");
		user_mem[i].syscall_req_level = _SA_p->_SA_log_arr[i].syscall_req_level;
		user_mem[i].proc_level = _SA_p->_SA_log_arr[i].proc_level;
		user_mem[i].time = _SA_p->_SA_log_arr[i].time;
		_SA_p->_SA_log_arr[i].syscall_req_level = -1;
		_SA_p->_SA_log_arr[i].proc_level = -1;
		_SA_p->_SA_log_arr[i].time = -1;
	}
	for (i=size; i< _SA_p->_SA_log_size; i++){
//		printk("KUKU2:\n");
		_SA_p->_SA_log_arr[i-size].syscall_req_level = _SA_p->_SA_log_arr[i].syscall_req_level;
		_SA_p->_SA_log_arr[i-size].proc_level = _SA_p->_SA_log_arr[i].proc_level;
		_SA_p->_SA_log_arr[i-size].time = _SA_p->_SA_log_arr[i].time;
	}
	for (i=(_SA_p->_SA_log_size)-size; i < _SA_p->_SA_log_size; i++){
		_SA_p->_SA_log_arr[i].syscall_req_level = -1;
		_SA_p->_SA_log_arr[i].proc_level = -1;
		_SA_p->_SA_log_arr[i].time = -1;
	}

	/*user_mem =  =================================== */
	return 0;
}

